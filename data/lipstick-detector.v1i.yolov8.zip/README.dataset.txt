# lipstick-detector > 2025-12-29 9:50pm
https://universe.roboflow.com/computer-vision-projects-h6dy2/lipstick-detector-75bnw

Provided by a Roboflow user
License: CC BY 4.0

